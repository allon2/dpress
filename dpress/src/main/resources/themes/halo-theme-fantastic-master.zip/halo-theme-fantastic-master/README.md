## TODO
- [x] 文章TOC(目录)功能
- [x] 添加相册功能(已经添加 `域名/photos`可以查看)、细节需要调整，目前还在考虑中。
- [x] 添加暗黑模式(已完成)
    - [x] 基本适配(可用)
    - [ ] 细节优化

## 修改了什么
 参见： [CHANGELOG](https://github.com/imkundev/halo-theme-fantastic/blob/master/CHANGELOG.md)
## 预览地址
[访问](https://www.imkun.dev)
## 使用前必看
[Fantastic 主题使用指南](https://www.imkun.dev/archives/Fantastic%20主题使用指南)
## 预览截图
![Screenshot_20191019 知否1.png](https://www.imkun.dev/upload/2019/10/Screenshot_2019-10-19%20%E7%9F%A5%E5%90%A6(1)-6ab44dfe61584f40aa80eee0f4e8b03c.png)

![Screenshot_20191019 知否.png](https://www.imkun.dev/upload/2019/10/Screenshot_2019-10-19%20%E7%9F%A5%E5%90%A6-d922f147a53d4a7490d1ad0eeb0d4acf.png)

## 使用方法
1. 克隆或者[下载](https://codeload.github.com/imkundev/halo-theme-fantastic/zip/master)。
2. 压缩为 zip 压缩包之后在后台的主题设置直接上传即可使用。
3. 用Halo自还的程序拉取 `https://github.com/imkundev/halo-theme-fantastic.git`
