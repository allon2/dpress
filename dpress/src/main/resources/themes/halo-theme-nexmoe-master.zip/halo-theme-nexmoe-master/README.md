<h1 align="center">halo-theme-nexmoe</h1>

[![stars](https://flat.badgen.net/github/stars/coortop/halo-theme-nexmoe?icon=github)](https://github.com/coortop/halo-theme-nexmoe)

[弥枳](https://blog.coor.top)

本主题为halo博客系统主题，移植于hexo博客系统的hexo-theme-nexmoe主题

### 使用帮助

[帮助文档](https://github.com/coortop/halo-theme-nexmoe/blob/master/question.md)

## 预览图
![screenshot.png](https://cdn.jsdelivr.net/gh/coortop/halo-theme-nexmoe@master/screenshot.png)