$(function () {
    sagiri.affix(700, 465);
    sagiri.lazyload('img.lazy');
});
