## 2.0.3

- Added an option that controls the visibility of 'Archives' in navigation sections. (#16)
- Added the support for using external image resources as feature images in posts or pages. (#15)

## 2.0.2

- Scroll bar issues fixed and favicon support added with #11 by @drrrMikado

## 2.0.1

- Added back the missing page indicator in mobile layout
- Copyright information in mobile layout will use current year automatically

## 2.0.0

New-generation release

## 1.0.0

Initial release