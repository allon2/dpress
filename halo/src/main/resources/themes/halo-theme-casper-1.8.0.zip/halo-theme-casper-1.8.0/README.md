<h1><a href="https://github.com/halo-dev" target="_blank">halo-theme-casper</a></h1>

# 主分支的代码已经不适用于 Halo 0.x ，请移步 release 下载旧版本

## Description

The original author of this theme is [Ghost](https://github.com/TryGhost),Thanks very much for making such a great theme.

Original subject address：[https://github.com/TryGhost/Casper](https://github.com/TryGhost/Casper)

## Preview screenshot

![index](https://i.loli.net/2019/05/29/5ced6b8f66c0298030.png)

![settings](https://i.loli.net/2019/05/29/5ced6b9178edf29128.png)

## Preview address

[Ghost](https://demo.ghost.io)

## Instructions

1. Clone or [download](https://github.com/halo-dev/halo-theme-casper/releases).
2. After compressing to a zip archive, you can use it directly in the background settings of the background.

